# ShieldBOT

Bot został stworzony w bibliotece [discord.js](https://discord.js.org/), Stworzyłem go dla siebie ale z powodu tego że piszę ShieldBOT'a 2.0\n
I nie oceniajcie tego jak pisałem całego bota bo jest to pierwszy bot którego napisałem dla publiki, w ShieldBOT'cie 2.0 będzie lepszy handler itp.

# Linki ShieldBOT'a
#### [Strona bot'a](https://shieldbot.gq/)
#### [Link dodania](https://discord.com/oauth2/authorize?client_id=831470538480025610&permissions=8&scope=bot)
#### [Serwer Support](https://discord.gg/Gse4bKF3)
#### [Dokumentacja](https://solindeklive-biznes.gitbook.io/shield-bot/)
