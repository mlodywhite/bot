module.exports = {
    token: "",
    prefix: "s!",
    botversion: "1.1",
    botauthor: "deloskiyt#1337",
    botstrona: "https://offline/",
    hostdatabase: '54.38.50.59',
    userdatabase: 'www10308_waterbot',
    passworddatabase: 'sPJqk6a3cBytmw2YwQXf',
    databasedb: 'www10308_waterbot'
}