---
name: Błąd
about: Użyj tego szablonu by zgłosić błąd.
labels: 'bug'
---

**Opisz aktualne zachowanie**

**Opisz oczekiwane zachowanie**

**Inne informacje / logi** Zawrzyj jakiekolwiek logi lub kod źródłowy, który pomoże zdiagnozować problem. Duże logi oraz pliki powinny zostać załączone.
