---
name: Prośba o usunięcie funkcji
about: Użyj tego szablonu jeśli sądzisz, że jakaś funkcja jest niepotrzebna.
labels: 'delete'
---

**Funkcja, którą chcesz usunąć.**

**Czemu sądzisz, że funkcja jest niepotrzebna i wymaga usunięcia.**

**Inne informacje.**
