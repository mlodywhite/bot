---
name: Prośba o funkcję
about: Użyj tego szablonu aby zasugerować funkcję.
labels: 'feature'
---

**Opisz aktualne zachowanie/stan**

**Opisz funkcję. Co ona doda?**

**Kto skorzysta z tej funkcji? Czemu twoja funkcja powinna zostać wprowadzona?**

**Inne informacje. (np. : sposób wprowadzenia)**
