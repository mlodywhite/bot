---
name: Pytanie
about: Użyj tego szablonu jeśli chcesz zadać pytanie lub otrzymać pomoc.
labels: 'question'
---

**Twoje pytanie :** Staraj się załączyć wszystkie piliki oraz zrzuty z ekranu bez dodawania linków, gdyż te mogą się zmieniać.
